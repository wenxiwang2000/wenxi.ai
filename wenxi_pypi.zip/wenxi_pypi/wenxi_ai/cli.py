
def main():
    print("Welcome to Wenxi AI tools 🚀")
