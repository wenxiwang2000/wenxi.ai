
# Wenxi AI

A collection of useful AI and data tools.

## Install

pip install wenxi-ai

## Run

wenxi
